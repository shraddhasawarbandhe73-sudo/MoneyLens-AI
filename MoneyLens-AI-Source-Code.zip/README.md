# MoneyLens AI

**Your Personal Finance Dashboard — prototype**

MoneyLens AI is a front-end prototype that presents a simple personal-finance dashboard with an overview of income, expenses, sample spending categories, recent transactions, and explanatory spending insights.

## Current implementation

- Responsive HTML/CSS dashboard.
- Illustrative sample financial data.
- Static spending-category bars and sample transaction table.
- Small JavaScript interactions for a demo summary and reset.

## Run locally

1. Download or clone this repository.
2. Open `index.html` in a modern web browser.

No build tools, package installation, API keys, or server are required.

## Important implementation and integration status

This repository currently contains a **front-end prototype only**.

- **PayPal:** PayPal Developer / Sandbox integration is **not implemented** in this version. No PayPal SDK, checkout, order creation, capture, or sandbox transaction is performed.
- **AI:** No AI model or AI service is called by this version. The displayed insights are static explanatory demo text, not model-generated financial recommendations.
- **Other technologies:** HTML, CSS, and vanilla JavaScript.

Do not enter real financial information. All figures shown are illustrative sample data. The prototype does not connect to bank accounts, process payments, or provide financial, investment, tax, or legal advice.

## Roadmap

Potential future work includes adding an AI service for explainable budgeting insights and implementing PayPal Checkout using PayPal's developer Sandbox credentials and server-side order creation/capture. These are planned items, not completed features.

## License

Released under the MIT License. See [LICENSE](LICENSE).
